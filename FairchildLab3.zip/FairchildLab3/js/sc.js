var map = L.map('map').setView([37.8, -96], 4);

var tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

fetch('https://cdn.glitch.global/ebee96ab-e849-4b26-bece-8da2ab8c5777/vector_layer.geojson?v=1698435015719') 
.then(function (response) {
return response.json();
})
.then(function (data) {
L.geoJSON(data, {
  pointToLayer: function (feature, latlng) {
    var symbolSize = feature.properties.POPULATION / 250000;
    return L.circleMarker (latlng, {
      radius: symbolSize,
      fillColor: "blue",
      color: "blue",
      weight: 1,
      opacity: 1,
      fillOpacity: 0.7
    });
  },
  onEachFeature: function (feature, layer) {
    var popupContent = "Name: " + feature.properties.NAME +
    "<br>Population: " + feature.properties.POPULATION +
    "<br>State: " + feature.properties.ST;
    layer.bindPopup(popupContent);
  }
}).addTo(map);
});

  

    













